package test_sopra_steria;
import java.util.Scanner;

public class ejercicio3 {

	public static void main(String[] args) {
		
		

        // Declarar variables
        int HORASTRABAJADAS; // Variable para las horas trabajadas
        double TARIFA;       // Variable para la tarifa por hora
        double SUELDO;      // Variable para el sueldo total
        int HORAS_EXTRAS;   // Variable para las horas extras
        double TARIFA_EXTRAS; // Variable para la tarifa incrementada

        
        // Para leer los datos
        Scanner scanner = new Scanner(System.in);
        System.out.print("Ingrese las horas trabajadas: ");
        HORASTRABAJADAS = scanner.nextInt();
        System.out.print("Ingrese la tarifa por hora: ");
        TARIFA = scanner.nextDouble();

        // Inicializar variables
        SUELDO = 0;
        HORAS_EXTRAS = 0;
        TARIFA_EXTRAS = TARIFA * 1.5; // Incremento del 50%

        // Calculo del sueldo
        
        //si la cantidad de horas trabajadas es mayor a 40 horas, la tarifa se incrementa en un 50% para las horas extras
        if (HORASTRABAJADAS > 40) {
            HORAS_EXTRAS = HORASTRABAJADAS - 40;
            SUELDO = (40 * TARIFA) + (HORAS_EXTRAS * TARIFA_EXTRAS);
        } else {
            SUELDO = HORASTRABAJADAS * TARIFA;
        }

        // Mostrar el resultado
        System.out.printf("El sueldo recibido por el trabajador es: %.2f\n", SUELDO);

        // Cerrar el escáner
        scanner.close();

	}

}
