package test_sopra_steria;
import java.util.Scanner;

public class ejercicio_1 {

	public static void main(String[] args) {
		
		int NUMERO;
		
		
		//lectura de variable entero
        Scanner scanner = new Scanner(System.in);
        System.out.print("Ingrese un número entero: ");
        NUMERO = scanner.nextInt();
        
        //comparacion para ver si es par o impar
        if (NUMERO % 2 == 0) {
            //Par, imprimir pares de manera descendente desde el número hasta 0
            System.out.println("Números pares de " + NUMERO + " de manera decreciente:");
            for (int i = NUMERO; i >= 0; i -= 2) {
                System.out.println(i);
            }
        } else {
            // Impar, imprimir impares de manera descendente desde el número hasta 1
            System.out.println("Números impares de" + NUMERO + " de manera decreciente:");
            for (int i = NUMERO; i >= 1; i -= 2) {
                System.out.println(i);
            }
        }
        
        scanner.close();
 
	}

}
