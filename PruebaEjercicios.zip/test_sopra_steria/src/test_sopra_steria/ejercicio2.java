package test_sopra_steria;
import java.util.Scanner;

public class ejercicio2 {

    // Creo una clase para poder almacenar dentro de la variable PERSONA los dos campos sexo y edad
    static class PERSONA {
        String SEXO;
        int EDAD;

        PERSONA(String SEXO, int EDAD) {
            this.SEXO = SEXO;
            this.EDAD = EDAD;
        }
    }

    public static void main(String[] args) {
        
 
        // Lectura de datos de las 50 personas (ojo aqui no esta con verificacion de los datos ingresados)
    	Scanner scanner = new Scanner(System.in);
    	PERSONA[] personas = new PERSONA[50];
        for (int i = 0; i < 50; i++) {
            System.out.print("Ingrese el SEXO de la persona " + (i + 1) + " (masculino=M/femenino=F): ");
            String SEXO = scanner.next().toLowerCase();
            System.out.print("Ingrese la EDAD de la persona " + (i + 1) + ": ");
            int EDAD = scanner.nextInt();
            personas[i] = new PERSONA(SEXO, EDAD); // Crear y almacenar la PERSONA
        }

        // Para los contadores
        int mayoresDeEdad = 0;
        int menoresDeEdad = 0;
        int hombresMayores = 0;
        int mujeresMenores = 0;

        //Clasifico los datos de PERSONAS
        for (PERSONA persona : personas) {
            //Para identificar mayores de edad
        	if (persona.EDAD >= 18) {
                mayoresDeEdad++;
            //Para identificar el sexo de la persona
                if (persona.SEXO.equals("M")) {
                    hombresMayores++;
                }
            } else {
                menoresDeEdad++;
                if (persona.SEXO.equals("F")) {
                    mujeresMenores++;
                }
            }
        }

        // Calcular porcentajes
        double porcentajeMayoresDeEdad = (mayoresDeEdad / 50.0) * 100;
        double porcentajeMujeres = ((50 - hombresMayores) / 50.0) * 100; // Total - hombres

        //
        System.out.println("a.Cantidad de personas mayores de edad: " + mayoresDeEdad);
        System.out.println("b.Cantidad de personas menores de edad: " + menoresDeEdad);
        System.out.println("c.Cantidad de personas masculinas mayores de edad: " + hombresMayores);
        System.out.println("d.Cantidad de personas femeninas menores de edad: " + mujeresMenores);
        System.out.printf("e.Porcentaje de personas mayores de edad respecto al total: %.2f%%\n", porcentajeMayoresDeEdad);
        System.out.printf("f.Porcentaje de mujeres respecto al total: %.2f%%\n", porcentajeMujeres);

        // Cerrar el escáner
        scanner.close();
    }
}
